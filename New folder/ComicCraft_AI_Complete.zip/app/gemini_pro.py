from google import genai
from google.genai import types

from app.config import settings
from app.schemas import OutlineResponse, PromptRequest, StoryResponse

def _client():
    if not settings.gemini_api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Add it to .env or set AI_MODE=demo."
        )
    return genai.Client(api_key=settings.gemini_api_key)

def generate_story(request: PromptRequest, outline: OutlineResponse) -> StoryResponse:
    if settings.ai_mode.lower() == "demo":
        panels = []
        for p in outline.panels:
            panels.append({
                "panel_number": p.panel_number,
                "title": p.title,
                "scene_description": f"{request.character_name} is in {request.setting}.",
                "caption": "A new moment begins...",
                "narration": f"{request.character_name} takes a brave step forward.",
                "dialogue": f"{request.character_name}: We can do this!",
            })
        return StoryResponse(panels=panels)

    prompt = f"""
Expand this comic outline into polished comic narration and dialogue.

User inputs:
Story: {request.story_prompt}
Character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}

Outline:
{outline.model_dump_json(indent=2)}

Requirements:
- Return one story object for every outline panel.
- Preserve panel numbers and titles.
- Keep continuity between panels.
- Each panel needs scene_description, caption, narration, and dialogue.
- Keep dialogue concise enough to fit inside a comic panel.
- Avoid graphic violence, sexual content, hateful content, or instructions for dangerous activities.
- Match the requested tone.
"""

    response = _client().models.generate_content(
        model=settings.gemini_story_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=StoryResponse,
            temperature=0.9,
        ),
    )
    result = StoryResponse.model_validate_json(response.text)
    if len(result.panels) != len(outline.panels):
        raise RuntimeError("Story generation returned an unexpected number of panels.")
    return result
