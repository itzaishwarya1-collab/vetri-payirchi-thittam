from typing import List
from app.schemas import OutlineResponse, StoryResponse

def build_comic_layout(
    outline: OutlineResponse,
    story: StoryResponse,
    image_paths: List[str],
) -> list[dict]:
    story_by_panel = {p.panel_number: p for p in story.panels}
    layout = []

    for index, outline_panel in enumerate(outline.panels):
        panel_story = story_by_panel.get(outline_panel.panel_number)
        if not panel_story:
            raise RuntimeError(
                f"Missing story content for panel {outline_panel.panel_number}."
            )
        layout.append({
            "panel_number": outline_panel.panel_number,
            "title": outline_panel.title,
            "image_url": image_paths[index],
            "scene_description": panel_story.scene_description,
            "caption": panel_story.caption,
            "narration": panel_story.narration,
            "dialogue": panel_story.dialogue,
            "image_prompt": outline_panel.image_prompt,
        })
    return layout
