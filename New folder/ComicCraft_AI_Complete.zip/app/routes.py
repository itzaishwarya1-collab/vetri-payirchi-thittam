from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

from app.schemas import PromptRequest
from app.services import generate_comic

router = APIRouter()
templates = Jinja2Templates(directory="templates")

def _request_from_form(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
) -> PromptRequest:
    return PromptRequest(
        story_prompt=story_prompt,
        character_name=character_name,
        setting=setting,
        tone=tone,
        art_style=art_style,
    )

@router.get("/")
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={},
    )

@router.post("/generate")
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        prompt_request = _request_from_form(
            story_prompt, character_name, setting, tone, art_style
        )
        comic = generate_comic(prompt_request)
        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={"comic": comic.model_dump()},
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="error.html",
            context={"error": str(exc)},
            status_code=500,
        )

@router.post("/generate-comic/json")
async def generate_comic_json(payload: PromptRequest):
    try:
        return generate_comic(payload)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@router.get("/export-success")
async def export_success(request: Request, pdf: str = ""):
    return templates.TemplateResponse(
        request=request,
        name="export_success.html",
        context={"pdf_url": pdf},
    )

@router.get("/test-image")
async def test_image(prompt: str = "A brave fox exploring an enchanted forest"):
    from app.image_generator import generate_image
    try:
        image_url = generate_image(prompt, 999)
        return {"status": "ok", "image_url": image_url}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
