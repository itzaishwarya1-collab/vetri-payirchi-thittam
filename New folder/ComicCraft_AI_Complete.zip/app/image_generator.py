import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from huggingface_hub import InferenceClient

from app.config import settings

BASE_DIR = Path(__file__).resolve().parent.parent
PANELS_DIR = BASE_DIR / "static" / "panels"
PANELS_DIR.mkdir(parents=True, exist_ok=True)

def _safe_name(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "_", value).strip("_")
    return value[:80] or "panel"

def _demo_image(prompt: str, panel_number: int, filename: Path) -> None:
    image = Image.new("RGB", (settings.image_width, settings.image_height), "white")
    draw = ImageDraw.Draw(image)
    margin = 45
    draw.rounded_rectangle(
        (margin, margin, settings.image_width-margin, settings.image_height-margin),
        radius=28,
        outline="black",
        width=5,
    )
    draw.text((70, 80), f"COMICCRAFT — PANEL {panel_number}", fill="black")
    lines = [
        "Demo image mode",
        "",
        "Add HF_TOKEN to generate",
        "real AI illustrations.",
        "",
        prompt[:180],
    ]
    y = 180
    for line in lines:
        draw.text((70, y), line, fill="black")
        y += 42
    image.save(filename, format="PNG")

def generate_image(image_prompt: str, panel_number: int) -> str:
    filename = PANELS_DIR / f"{_safe_name(f'panel_{panel_number}')}.png"

    if settings.ai_mode.lower() == "demo":
        _demo_image(image_prompt, panel_number, filename)
        return f"/static/panels/{filename.name}"

    if not settings.hf_token:
        raise RuntimeError(
            "HF_TOKEN is missing. Add it to .env or set AI_MODE=demo."
        )

    client = InferenceClient(
        provider=settings.hf_provider,
        api_key=settings.hf_token,
    )
    prompt = (
        f"{image_prompt}. Comic illustration, clear composition, expressive characters, "
        f"consistent visual storytelling, no text, no watermark."
    )
    image = client.text_to_image(
        prompt=prompt,
        model=settings.hf_image_model,
    )
    image.save(filename, format="PNG")
    return f"/static/panels/{filename.name}"
