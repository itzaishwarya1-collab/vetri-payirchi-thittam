from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.routes import router

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
TEMPLATES_DIR = BASE_DIR / "templates"

for directory in [
    STATIC_DIR / "panels",
    STATIC_DIR / "exports",
    STATIC_DIR / "css",
]:
    directory.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title="ComicCraft",
    description="AI Comic Story Creator using Gemini and Hugging Face",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.include_router(router)

@app.get("/health")
async def health():
    return {"status": "ok", "service": "ComicCraft"}
