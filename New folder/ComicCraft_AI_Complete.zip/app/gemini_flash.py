from google import genai
from google.genai import types

from app.config import settings
from app.schemas import OutlineResponse, PromptRequest, PanelOutline, PanelOutline

def _client():
    if not settings.gemini_api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Add it to .env or set AI_MODE=demo."
        )
    return genai.Client(api_key=settings.gemini_api_key)

def generate_outline(request: PromptRequest) -> OutlineResponse:
    if settings.ai_mode.lower() == "demo":
        return OutlineResponse(panels=[
            PanelOutline(panel_number=i, title=f"Panel {i}", scene_description="", image_prompt="")
            for i in range(1, settings.panels_count + 1)
        ])

    class OutlineModel(OutlineResponse):
        pass

    prompt = f"""
Create a coherent {settings.panels_count}-panel comic outline.

User story idea: {request.story_prompt}
Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}

Requirements:
- Exactly {settings.panels_count} panels.
- Each panel must advance the story.
- Keep the same main character throughout.
- Write concise scene descriptions.
- Write detailed image-generation prompts suitable for an image model.
- Do not put dialogue in image_prompt.
- Return only the requested structured data.
"""

    response = _client().models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=OutlineResponse,
            temperature=0.8,
        ),
    )
    result = OutlineResponse.model_validate_json(response.text)
    if len(result.panels) != settings.panels_count:
        raise RuntimeError(
            f"Gemini returned {len(result.panels)} panels; expected {settings.panels_count}."
        )
    return result
