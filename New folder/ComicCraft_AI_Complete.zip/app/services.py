from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf
from app.schemas import ComicResponse, PromptRequest

def generate_comic(request: PromptRequest) -> ComicResponse:
    outline = generate_outline(request)
    story = generate_story(request, outline)

    image_paths = [
        generate_image(panel.image_prompt, panel.panel_number)
        for panel in outline.panels
    ]

    layout = build_comic_layout(outline, story, image_paths)
    title = f"{request.character_name}'s Comic"
    pdf_url = save_pdf(title, layout)

    return ComicResponse(title=title, panels=layout, pdf_url=pdf_url)
